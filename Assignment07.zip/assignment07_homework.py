# ---------------------------------------
# Title:  Assignment07 script (Exception Handling and Python Pickling)
# Name:  Kyle Chan
# Date:  Feb 24, 2019
# Course:  Intro to Python
# Comments:  This code goes with Intro
# to Python Class Assignment087
# This assignment is to create a simple script to showcase
# Python's Exception Handling and Pickling

# Import Pickle module
import pickle

# Simple example of Exception Handling and use of Pickling
# Ask User to input two numbers and do some math
# Raise exception is numbers are greater than 100
# Throw error if input is not number with ValueError
# Throw error if dividing by zero with ZeroDivisionError
# This helps the user input the right things in the input command
# Store data with pickle.dump method
#

try:
    # Get user input for numbers
    x = float(input('Select number (x) that is less than 100: '))
    y = float(input('Select number (y) that is less than 100: '))

    # Throw exceptions if larger than 100
    if x > 100:
        raise Exception("x should not exceed 100.  The value of x was: {}".format(x))
    if y > 100:
        raise Exception("y should not exceed 100.  The value of y was: {}".format(y))
    # Do math operations
    line_one = ("The sum of x + y = ", x+y)
    line_two = ("The difference of x - y = ", x-y)
    line_three = ("The product of x*y = ", x*y)
    line_four = ("The quotient of x/y = ", x/y)

    # Save Data as list
    lstData = [line_one, line_two, line_three, line_four]


    # Now we store the data with the pickle.dump method
    objFile = open("C:\_PythonClass\Assignment07\save_numbers.dat", "ab")
    pickle.dump(lstData, objFile)
    objFile.close()

    # load data from pickle
    objFile = open("C:\_PythonClass\Assignment07\save_numbers.dat", "rb")
    objFileData = pickle.load(objFile)  # Note that load() only load one row
    for line in objFileData:
        print(line)

# Print Exception errors
except ValueError as v:
    print("User input must be a number")
except ZeroDivisionError as e:
    print("Do not divide by zero")

