# ---------------------------------------
# Title:  Assignment05 script (To Do List managing!)
# Name:  Kyle Chan
# Date:  Feb 10, 2019
# Course:  Intro to Python
# Comments:  This code goes with Intro
# to Python Class Assignment05
# Create Python script file that manages a To Do list
# Store data in a Python Dictionary
# Create conditional loop with user options
# Save file to Todo.txt

# First is to read current data from Todo.txt file
objFile = open("Todo.txt",'r')

# Create empty list to store data when reading file and when asking data from user
lstData = []

# Read the text file line by line and save as a Dictionary
# First is Task, Second is priority
for line in objFile:
    line = line.replace("\n","")  # Remove \n with space
    dataLine = line.split(",",1)  # Split line based on Comma
    strTask = dataLine[0]  # First is Task
    strPriority = dataLine[1] # Second is Priority
    dictNewRow = {"Task":strTask, "Priority":strPriority} # Combine into Dictionary
    lstData.append(dictNewRow)  # Put into list
objFile.close()

# Once original file is read, ask user for what the next tasks are
# Display menu of choices to the uer
while(True):
    print("""
    Menu of Options
    1) Show Current Data
    2) Add a new item
    3) Remove an Existing Item
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print() # Adding new line

    # Show the current items in the list (Option 1)
    if strChoice.strip() == "1":
        print("Here is what currently is in the data set:")
        print("Task", "/", "Priority") # Sort of Title Block
        for item in lstData:
            strTaskOutput = item.get("Task")
            strPriorityOutput = item.get("Priority")
            print(strTaskOutput, "/", strPriorityOutput)

    # Add new item to the list (Option 2)
    elif strChoice.strip() == "2":
        strTaskInput = str(input("What is the Task? "))
        strPriorityInput = str(input("What is the Priority of this Task: [High/Medium/Low] "))

        # Add new user inputs as dictionary and add to list
        dictNewRow = {"Task": strTaskInput, "Priority": strPriorityInput}
        lstData.append(dictNewRow)

    # Remove an existing item (Option 3)
    elif strChoice.strip() == "3":

        # First print data to see what is there
        print("Here are the current list of tasks: ")

        # Get List of Tasks from lstData
        lstTasks = [d["Task"] for d in lstData]

        for tasks in lstTasks:
            print(tasks)

        # Ask user which Tasks should be deleted
        strTaskDelete = input("Which Task should be deleted: (Must be Case-sensitive!) ")

        # Create counter to find index position within list
        count_tasks = 0
        for item in lstTasks:
            if strTaskDelete in item:  # If True, delete list with index of count_tasks
                lstData.pop(count_tasks)
                break
            else:
                count_tasks = count_tasks + 1

    # Save Tasks to the Todo.txt file
    elif strChoice.strip() == "4":
        objFile = open("Todo.txt","w")
        for l in lstData:
            objFile_task = l.get("Task")
            objFile_Priority = l.get("Priority")
            objFile.write("%s , %s\n" % (objFile_task, objFile_Priority))  # write to file
        objFile.close()
        print("Data saved to file!")

    # Exit Program
    elif strChoice.strip() == "5":
        break  # Exit program

    else:
        print("Invalid entry!")

# After breaking while loop, save the data in Todo.txt file
objFile = open("Todo.txt", "w")
for l in lstData:
    objFile_task = l.get("Task")
    objFile_Priority = l.get("Priority")
    objFile.write("%s , %s\n" % (objFile_task, objFile_Priority)) # write to file
objFile.close()
print("Data saved to file!")



